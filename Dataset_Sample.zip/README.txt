﻿The Web Index — Free Multilingual Sample Dataset
===========================================

What’s included
---------------
• A preview extract from web.wiki, the multilingual encyclopedia with 3.5M+ pages across 165 languages.
• This sample includes 5 languages × 100 rows each (English, Simplified Chinese, Spanish, Arabic, Hindi).
• Data is provided in CSV (UTF-8 with BOM), mirroring the exact schema of the full Web Index datasets.

Columns
-------
- id (Int)                    : Stable row key across languages
- post_parent (Int|empty)     : Parent row id (empty = root page)
- parent_slug (Str|empty)     : Parent slug (empty = root page)
- post_name (Str)             : Canonical slug (English normalized)
- url (Str)                   : https://web.wiki/<lang_iso>/<hierarchical-path>/
- rank_math_title (Str)       : SEO title (English prefix + localized suffix)
- rank_math_description (Str) : Localized SEO description
- post_title (Str)            : English Normalized title (H1)
- content_1 (Str|empty)       : Body block 1
- content_2 (Str|empty)       : Body block 2
- lang_iso (Str)              : Language/site code for this file

URL behavior
------------
• Root pages render under the language: https://web.wiki/<lang_iso>/<domain>/
• Library sections render as:           https://web.wiki/<lang_iso>/library/<domain>/
• Deep pages reflect the site hierarchy with clean, human-readable slugs.

License & Legal
---------------
• This free sample dataset is provided by web.wiki for evaluation, research, and educational purposes only.
• Redistribution, resale, or repackaging of this dataset, in whole or in part, is not permitted without prior written consent.
• Delivered “as is,” without warranties of any kind.
• For complete datasets covering all 165 languages, visit: https://thewebindex.gumroad.com

Generated
---------
2025-09-30
